class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None  # acts as left
        self.next = None  # acts as right

def convert_to_binary_tree(head):
    if not head:
        return None
    root = head
    queue = [root]
    head = head.next
    while head:
        parent = queue.pop(0)
        parent.prev = head
        queue.append(head)
        head = head.next
        if head:
            parent.next = head
            queue.append(head)
            head = head.next
    return root

def inorder(root):
    if root:
        inorder(root.prev)
        print(root.data, end=" ")
        inorder(root.next)

head = Node(10)
head.next = Node(20)
head.next.prev = head
head.next.next = Node(30)
head.next.next.prev = head.next

root = convert_to_binary_tree(head)
inorder(root)