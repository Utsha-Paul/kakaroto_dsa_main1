class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = new_node
        new_node.prev = temp

    def divide_and_rejoin_reverse(self):
        slow = fast = self.head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next

        second_half = slow
        if second_half.prev:
            second_half.prev.next = None
        second_half.prev = None

        def reverse(head):
            prev = None
            curr = head
            while curr:
                next_node = curr.next
                curr.next = prev
                if prev:
                    prev.prev = curr
                prev = curr
                curr = next_node
            return prev

        first_half_reversed = reverse(self.head)
        second_half_reversed = reverse(second_half)

        temp = first_half_reversed
        while temp.next:
            temp = temp.next
        temp.next = second_half_reversed
        if second_half_reversed:
            second_half_reversed.prev = temp

        self.head = first_half_reversed

    def display(self):
        temp = self.head
        while temp:
            print(temp.data, end=" <-> ")
            temp = temp.next
        print("None")

dll = DoublyLinkedList()
for i in [11,22,33,44,55,66]:
    dll.append(i)
dll.divide_and_rejoin_reverse()
dll.display()