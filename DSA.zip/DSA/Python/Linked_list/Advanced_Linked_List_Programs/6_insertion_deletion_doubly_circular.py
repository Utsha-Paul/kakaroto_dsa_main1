class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoublyCircularLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            new_node.next = new_node.prev = new_node
        else:
            tail = self.head.prev
            tail.next = new_node
            new_node.prev = tail
            new_node.next = self.head
            self.head.prev = new_node

    def delete(self, key):
        if not self.head:
            return
        curr = self.head
        prev = None
        while True:
            if curr.data == key:
                if curr == self.head:
                    if curr.next == self.head:
                        self.head = None
                    else:
                        tail = self.head.prev
                        self.head = self.head.next
                        tail.next = self.head
                        self.head.prev = tail
                else:
                    curr.prev.next = curr.next
                    curr.next.prev = curr.prev
                break
            curr = curr.next
            if curr == self.head:
                break

    def display(self):
        if not self.head:
            print("Empty list")
            return
        temp = self.head
        while True:
            print(temp.data, end=" <-> ")
            temp = temp.next
            if temp == self.head:
                break
        print()

dcll = DoublyCircularLinkedList()
for i in [10, 20, 30, 40, 50]:
    dcll.insert(i)
dcll.display()
dcll.delete(30)
dcll.display()