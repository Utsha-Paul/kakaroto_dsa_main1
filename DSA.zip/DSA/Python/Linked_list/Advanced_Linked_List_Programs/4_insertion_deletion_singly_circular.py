class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyCircularLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_position(self, data, pos):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            self.head.next = self.head
            return
        if pos == 0:
            temp = self.head
            while temp.next != self.head:
                temp = temp.next
            temp.next = new_node
            new_node.next = self.head
            self.head = new_node
            return
        temp = self.head
        for _ in range(pos - 1):
            temp = temp.next
            if temp == self.head:
                break
        new_node.next = temp.next
        temp.next = new_node

    def delete_at_position(self, pos):
        if not self.head:
            print("List empty")
            return
        temp = self.head
        if pos == 0:
            while temp.next != self.head:
                temp = temp.next
            temp.next = self.head.next
            self.head = self.head.next
            return
        for _ in range(pos - 1):
            temp = temp.next
        temp.next = temp.next.next

    def display(self):
        temp = self.head
        while True:
            print(temp.data, end=" -> ")
            temp = temp.next
            if temp == self.head:
                break
        print()

cll = SinglyCircularLinkedList()
for i in [1, 2, 3, 4, 5]:
    cll.insert_at_position(i, i-1)
cll.display()
cll.delete_at_position(2)
cll.display()