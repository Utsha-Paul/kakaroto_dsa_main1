class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def left_shift(head, k):
    if not head or k == 0:
        return head
    tail = head
    length = 1
    while tail.next:
        tail = tail.next
        length += 1
    tail.next = head
    k = k % length
    for _ in range(length - k):
        tail = tail.next
    new_head = tail.next
    tail.next = None
    return new_head