class Node:
    def __init__(self, coeff, power):
        self.coeff = coeff
        self.power = power
        self.next = None

def add_polynomials(poly1, poly2):
    result = Node(0, 0)
    temp = result
    while poly1 and poly2:
        if poly1.power > poly2.power:
            temp.next = Node(poly1.coeff, poly1.power)
            poly1 = poly1.next
        elif poly1.power < poly2.power:
            temp.next = Node(poly2.coeff, poly2.power)
            poly2 = poly2.next
        else:
            temp.next = Node(poly1.coeff + poly2.coeff, poly1.power)
            poly1 = poly1.next
            poly2 = poly2.next
        temp = temp.next
    temp.next = poly1 or poly2
    return result.next