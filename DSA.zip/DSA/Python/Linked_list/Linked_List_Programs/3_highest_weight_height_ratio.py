class Node:
    def __init__(self, height, weight):
        self.height = height
        self.weight = weight
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, height, weight):
        new_node = Node(height, weight)
        if not self.head:
            self.head = new_node
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = new_node

    def find_highest_ratio(self):
        max_ratio = 0
        temp = self.head
        while temp:
            ratio = temp.weight / temp.height
            if ratio > max_ratio:
                max_ratio = ratio
            temp = temp.next
        return max_ratio

# Example
students = LinkedList()
students.append(1.6, 60)
students.append(1.7, 70)
students.append(1.8, 68)
print("Highest weight/height ratio:", students.find_highest_ratio())