class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

def pairwise_swap(head):
    if not head or not head.next:
        return head
    prev = head
    curr = head.next
    head = curr
    while True:
        next_pair = curr.next
        curr.next = prev
        if not next_pair or not next_pair.next:
            prev.next = next_pair
            break
        prev.next = next_pair.next
        prev = next_pair
        curr = prev.next
    return head