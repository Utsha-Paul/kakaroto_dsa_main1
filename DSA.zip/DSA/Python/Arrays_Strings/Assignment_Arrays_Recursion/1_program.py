# Program 1: Find Pair with Given Sum

def find_pair(arr, target, i=0, seen=set()):
    if i == len(arr):
        print("No pair found")
        return
    if target - arr[i] in seen:
        print(f"Pair found: ({arr[i]}, {target - arr[i]})")
        return
    seen.add(arr[i])
    find_pair(arr, target, i+1, seen)

arr = [8, 7, 2, 5, 3, 1]
find_pair(arr, 10)
