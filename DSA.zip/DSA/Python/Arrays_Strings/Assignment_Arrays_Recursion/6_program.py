# Program 6: Minimum Index of Repeating Element

def min_index_repeat(arr):
    seen = {}
    min_index = float('inf')
    for i, val in enumerate(arr):
        if val in seen:
            min_index = min(min_index, seen[val])
        else:
            seen[val] = i
    print("Minimum index:", min_index if min_index != float('inf') else -1)

arr = [5, 6, 3, 4, 3, 6, 4]
min_index_repeat(arr)
