# Program 8: Largest Subarray with Consecutive Integers

def largest_consecutive_subarray(arr):
    max_len = 1
    for i in range(len(arr)-1):
        mn, mx = arr[i], arr[i]
        for j in range(i+1, len(arr)):
            mn, mx = min(mn, arr[j]), max(mx, arr[j])
            if mx - mn == j - i:
                max_len = max(max_len, j - i + 1)
    print("Largest length:", max_len)

arr = [2, 0, 2, 1, 4, 3, 1, 0]
largest_consecutive_subarray(arr)
