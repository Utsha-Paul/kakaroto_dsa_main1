# Program 10: Group Elements by First Occurrence

def group_by_first_occurrence(arr):
    seen = {}
    for val in arr:
        if val not in seen:
            seen[val] = []
        seen[val].append(val)
    print(list(seen.values()))

arr = [4, 3, 2, 4, 9, 2, 3, 4]
group_by_first_occurrence(arr)
