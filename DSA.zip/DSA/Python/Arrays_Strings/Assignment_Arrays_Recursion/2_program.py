# Program 2: Check if Subarray with Zero Sum Exists

def zero_sum_exists(arr, i=0, curr_sum=0, sums=set()):
    if i == len(arr):
        return False
    curr_sum += arr[i]
    if curr_sum == 0 or curr_sum in sums:
        return True
    sums.add(curr_sum)
    return zero_sum_exists(arr, i+1, curr_sum, sums)

arr = [3, 4, -7, 1, 3, 3, 1, -4]
print("Exists" if zero_sum_exists(arr) else "Does not exist")
