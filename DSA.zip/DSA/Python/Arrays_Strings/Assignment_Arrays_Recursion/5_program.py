# Program 5: Max Length Subarray with Equal 0s and 1s

def max_len_equal_01(arr):
    for i in range(len(arr)):
        if arr[i] == 0:
            arr[i] = -1
    sum_map = {}
    curr_sum = 0
    max_len = 0
    for i, val in enumerate(arr):
        curr_sum += val
        if curr_sum == 0:
            max_len = i + 1
        if curr_sum in sum_map:
            max_len = max(max_len, i - sum_map[curr_sum])
        else:
            sum_map[curr_sum] = i
    print("Max length:", max_len)

arr = [0, 0, 1, 0, 1, 0, 1]
max_len_equal_01(arr)
