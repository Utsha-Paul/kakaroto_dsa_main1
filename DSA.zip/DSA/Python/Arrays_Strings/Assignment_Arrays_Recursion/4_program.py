# Program 4: Maximum Length Subarray with Given Sum

def max_len_subarray(arr, target):
    sum_map = {}
    curr_sum = 0
    max_len = 0
    for i, val in enumerate(arr):
        curr_sum += val
        if curr_sum == target:
            max_len = i + 1
        if curr_sum - target in sum_map:
            max_len = max(max_len, i - sum_map[curr_sum - target])
        if curr_sum not in sum_map:
            sum_map[curr_sum] = i
    print("Max length:", max_len)

arr = [5, 8, -4, -4, 9, -2, 2]
max_len_subarray(arr, 0)
