# Program 7: Polynomial Rolling Hash

def poly_hash(s, p=31, m=10**9 + 9):
    def hash_recursive(s, i=0):
        if i == len(s):
            return 0
        return (ord(s[i]) - 96 + p * hash_recursive(s, i+1)) % m
    print("Hash:", hash_recursive(s))

poly_hash("abc")
