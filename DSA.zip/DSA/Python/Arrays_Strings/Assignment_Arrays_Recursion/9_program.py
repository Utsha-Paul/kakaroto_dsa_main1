# Program 9: Find Pairs with Difference K

def find_pairs_with_diff(arr, k, i=0, seen=set()):
    if i == len(arr):
        return
    if arr[i] - k in seen:
        print(f"Pair: ({arr[i]}, {arr[i]-k})")
    if arr[i] + k in seen:
        print(f"Pair: ({arr[i]}, {arr[i]+k})")
    seen.add(arr[i])
    find_pairs_with_diff(arr, k, i+1, seen)

arr = [8, 12, 16, 4, 0, 20]
find_pairs_with_diff(arr, 4)
