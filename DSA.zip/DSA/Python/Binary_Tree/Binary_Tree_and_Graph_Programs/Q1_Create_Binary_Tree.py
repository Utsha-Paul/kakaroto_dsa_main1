# Program 1: Create a Binary Tree using Recursion
class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def create_tree():
    data = input("Enter data (or 'None' to skip): ")
    if data == "None":
        return None
    node = Node(data)
    print(f"Enter left child of {data}:")
    node.left = create_tree()
    print(f"Enter right child of {data}:")
    node.right = create_tree()
    return node

def inorder(root):
    if root:
        inorder(root.left)
        print(root.data, end=" ")
        inorder(root.right)

if __name__ == "__main__":
    print("Create Binary Tree:")
    root = create_tree()
    print("\nInorder Traversal of Created Tree:")
    inorder(root)
    print()
