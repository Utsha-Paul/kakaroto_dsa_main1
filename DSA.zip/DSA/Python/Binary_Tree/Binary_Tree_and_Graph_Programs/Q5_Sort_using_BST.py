# Program 5: Sort a Given Set of Numbers using BST (Recursion)
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def insert(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert(root.left, key)
    else:
        root.right = insert(root.right, key)
    return root

def inorder(root, result):
    if root:
        inorder(root.left, result)
        result.append(root.key)
        inorder(root.right, result)

def bst_sort(arr):
    root = None
    for x in arr:
        root = insert(root, x)
    result = []
    inorder(root, result)
    return result

if __name__ == "__main__":
    arr = [7, 3, 9, 1, 5]
    print("Original Array:", arr)
    print("Sorted Array:", bst_sort(arr))
