# Program 9: Cycle Detection in Undirected Graph using Recursion
from collections import defaultdict

def add_edge(graph, u, v):
    graph[u].append(v)
    graph[v].append(u)

def has_cycle(graph, node, visited, parent):
    visited.add(node)
    for neighbor in graph[node]:
        if neighbor not in visited:
            if has_cycle(graph, neighbor, visited, node):
                return True
        elif neighbor != parent:
            return True
    return False

if __name__ == "__main__":
    graph = defaultdict(list)
    add_edge(graph, 0, 1)
    add_edge(graph, 1, 2)
    add_edge(graph, 2, 0)

    visited = set()
    print("Cycle Detected:", has_cycle(graph, 0, visited, -1))
