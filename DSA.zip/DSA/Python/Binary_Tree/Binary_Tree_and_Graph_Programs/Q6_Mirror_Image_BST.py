# Program 6: Find Mirror Image of a BST using Recursion
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def insert(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert(root.left, key)
    else:
        root.right = insert(root.right, key)
    return root

def mirror(root):
    if root:
        root.left, root.right = root.right, root.left
        mirror(root.left)
        mirror(root.right)

def inorder(root):
    if root:
        inorder(root.left)
        print(root.key, end=" ")
        inorder(root.right)

if __name__ == "__main__":
    root = None
    for x in [4, 2, 6, 1, 3, 5, 7]:
        root = insert(root, x)

    print("Original BST (Inorder):")
    inorder(root)
    print("\nMirror Image BST (Inorder):")
    mirror(root)
    inorder(root)
    print()
