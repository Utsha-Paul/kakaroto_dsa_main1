# Program 8: Two-Way Threaded Binary Tree using Recursion
class ThreadedNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
        self.lthread = False
        self.rthread = False

def insert(root, key):
    if root is None:
        return ThreadedNode(key)

    if key < root.data:
        if not root.left:
            temp = ThreadedNode(key)
            temp.left = root.left
            temp.right = root
            root.left = temp
            root.lthread = True
        else:
            insert(root.left, key)
    else:
        if not root.right:
            temp = ThreadedNode(key)
            temp.right = root.right
            temp.left = root
            root.right = temp
            root.rthread = True
        else:
            insert(root.right, key)
    return root

def inorder_traversal(root):
    if root:
        inorder_traversal(root.left)
        print(root.data, end=" ")
        inorder_traversal(root.right)

if __name__ == "__main__":
    root = None
    for val in [50, 30, 70, 20, 40, 60, 80]:
        root = insert(root, val)
    print("Inorder Traversal (Threaded Tree Simulation):")
    inorder_traversal(root)
    print()
