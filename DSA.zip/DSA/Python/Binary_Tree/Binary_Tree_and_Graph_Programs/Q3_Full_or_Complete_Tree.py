# Program 3: Check if Binary Tree is Full or Complete using Recursion
class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def is_full_tree(root):
    if root is None:
        return True
    if (root.left is None) != (root.right is None):
        return False
    return is_full_tree(root.left) and is_full_tree(root.right)

def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)

def is_complete(root, index=0, total_nodes=None):
    if root is None:
        return True
    if total_nodes is None:
        total_nodes = count_nodes(root)
    if index >= total_nodes:
        return False
    return (is_complete(root.left, 2*index+1, total_nodes) and
            is_complete(root.right, 2*index+2, total_nodes))

if __name__ == "__main__":
    root = Node(1)
    root.left = Node(2)
    root.right = Node(3)
    root.left.left = Node(4)
    root.left.right = Node(5)

    print("Full Tree:", is_full_tree(root))
    print("Complete Tree:", is_complete(root))
