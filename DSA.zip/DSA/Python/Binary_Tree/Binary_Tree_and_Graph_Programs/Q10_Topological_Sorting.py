# Program 10: Topological Sorting using Recursion
def topological_sort(graph):
    visited = set()
    stack = []

    def dfs(node):
        visited.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                dfs(neighbor)
        stack.insert(0, node)

    for node in graph:
        if node not in visited:
            dfs(node)
    return stack

if __name__ == "__main__":
    graph = {
        'A': ['C'],
        'B': ['C', 'D'],
        'C': ['E'],
        'D': ['F'],
        'E': ['H', 'F'],
        'F': ['G'],
        'G': [],
        'H': []
    }

    print("Topological Sort Order:")
    print(topological_sort(graph))
