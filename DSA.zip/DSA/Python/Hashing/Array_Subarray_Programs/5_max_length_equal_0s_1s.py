def max_len_equal_0s_1s(arr):
    n = len(arr)
    for i in range(n):
        if arr[i] == 0:
            arr[i] = -1
    prefix_sum = 0
    hashmap = {}
    max_len = 0
    for i in range(n):
        prefix_sum += arr[i]
        if prefix_sum == 0:
            max_len = i + 1
        if prefix_sum in hashmap:
            max_len = max(max_len, i - hashmap[prefix_sum])
        else:
            hashmap[prefix_sum] = i
    return max_len

arr = [0, 0, 1, 0, 1, 1, 0]
print("Max length subarray with equal 0s and 1s:", max_len_equal_0s_1s(arr))