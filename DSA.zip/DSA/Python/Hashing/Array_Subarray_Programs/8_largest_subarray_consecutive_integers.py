def largest_consecutive_subarray(arr):
    max_len = 0
    n = len(arr)
    for i in range(n):
        seen = set()
        min_val = arr[i]
        max_val = arr[i]
        for j in range(i, n):
            if arr[j] in seen:
                break
            seen.add(arr[j])
            min_val = min(min_val, arr[j])
            max_val = max(max_val, arr[j])
            if max_val - min_val == j - i:
                max_len = max(max_len, j - i + 1)
    return max_len

arr = [10, 12, 11, 14, 13, 15]
print("Largest subarray with consecutive integers length:", largest_consecutive_subarray(arr))