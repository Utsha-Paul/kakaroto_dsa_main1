def group_by_first_occurrence(arr):
    seen = {}
    for num in arr:
        seen.setdefault(num, []).append(num)
    grouped = [x for group in seen.values() for x in group]
    return grouped

arr = [4, 5, 6, 4, 5, 4, 7, 6]
print("Grouped array:", group_by_first_occurrence(arr))