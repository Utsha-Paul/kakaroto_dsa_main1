def print_zero_sum_subarrays(arr):
    prefix_sum = 0
    hashmap = {0: [-1]}
    for i in range(len(arr)):
        prefix_sum += arr[i]
        if prefix_sum in hashmap:
            for start in hashmap[prefix_sum]:
                print("Subarray:", arr[start+1:i+1])
        hashmap.setdefault(prefix_sum, []).append(i)

arr = [3, 4, -7, 1, 3, 3, 1, -4]
print_zero_sum_subarrays(arr)