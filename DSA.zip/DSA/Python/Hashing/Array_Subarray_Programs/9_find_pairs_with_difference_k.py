def find_pairs_with_diff(arr, k):
    seen = set(arr)
    pairs = []
    for num in arr:
        if num + k in seen:
            pairs.append((num, num + k))
    return pairs

arr = [1, 5, 3, 4, 2]
k = 2
print("Pairs with difference", k, ":", find_pairs_with_diff(arr, k))