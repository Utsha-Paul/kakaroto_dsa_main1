def find_pair_with_sum(arr, target):
    seen = set()
    for num in arr:
        if target - num in seen:
            return (num, target - num)
        seen.add(num)
    return None

arr = [10, 5, 2, 3, 7, 5]
target = 10
print("Pair with sum", target, ":", find_pair_with_sum(arr, target))