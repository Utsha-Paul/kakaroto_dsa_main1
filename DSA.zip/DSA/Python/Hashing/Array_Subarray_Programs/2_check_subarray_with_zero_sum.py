def has_zero_sum_subarray(arr):
    prefix_sum = 0
    seen = set()
    for num in arr:
        prefix_sum += num
        if prefix_sum == 0 or prefix_sum in seen:
            return True
        seen.add(prefix_sum)
    return False

arr = [4, 2, -3, 1, 6]
print("Zero sum subarray exists:" if has_zero_sum_subarray(arr) else "No zero sum subarray")