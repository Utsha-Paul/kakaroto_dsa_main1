def max_len_subarray_sum(arr, target):
    prefix_sum = 0
    hashmap = {}
    max_len = 0
    for i in range(len(arr)):
        prefix_sum += arr[i]
        if prefix_sum == target:
            max_len = i + 1
        if prefix_sum - target in hashmap:
            max_len = max(max_len, i - hashmap[prefix_sum - target])
        if prefix_sum not in hashmap:
            hashmap[prefix_sum] = i
    return max_len

arr = [10, 5, 2, 7, 1, 9]
target = 15
print("Maximum length subarray with sum", target, ":", max_len_subarray_sum(arr, target))