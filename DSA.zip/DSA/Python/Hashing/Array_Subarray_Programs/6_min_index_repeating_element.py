def min_index_repeating(arr):
    seen = {}
    min_index = float('inf')
    for i, val in enumerate(arr):
        if val in seen:
            min_index = min(min_index, seen[val])
        else:
            seen[val] = i
    return -1 if min_index == float('inf') else min_index

arr = [10, 5, 3, 4, 3, 5, 6]
print("Minimum index of repeating element:", min_index_repeating(arr))