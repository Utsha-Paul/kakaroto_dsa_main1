def polynomial_hash(s, base=31, mod=10**9 + 9):
    hash_value = 0
    power = 1
    for char in s:
        hash_value = (hash_value + (ord(char) - ord('a') + 1) * power) % mod
        power = (power * base) % mod
    return hash_value

s = "hello"
print("Polynomial Rolling Hash of", s, ":", polynomial_hash(s))