# Program 9: Reverse a Queue (Using Recursion)

from collections import deque

def reverse_queue(q):
    if not q:
        return
    data = q.popleft()
    reverse_queue(q)
    q.append(data)

q = deque([1, 2, 3, 4])
reverse_queue(q)
print("Reversed Queue:", list(q))
