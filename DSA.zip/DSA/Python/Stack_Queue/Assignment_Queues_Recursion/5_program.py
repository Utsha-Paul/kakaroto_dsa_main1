# Program 5: Dequeue Implementation

class Dequeue:
    def __init__(self):
        self.deque = []

    def insert_front(self, data):
        self.deque.insert(0, data)

    def insert_rear(self, data):
        self.deque.append(data)

    def delete_front(self):
        if self.deque:
            self.deque.pop(0)

    def delete_rear(self):
        if self.deque:
            self.deque.pop()

    def display(self):
        print("Dequeue:", self.deque)

dq = Dequeue()
dq.insert_rear(10)
dq.insert_front(5)
dq.delete_rear()
dq.display()
