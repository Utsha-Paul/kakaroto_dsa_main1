# Program 7: Stack using Queue

from collections import deque

class Stack:
    def __init__(self):
        self.q = deque()

    def push(self, data):
        self.q.append(data)
        for _ in range(len(self.q)-1):
            self.q.append(self.q.popleft())

    def pop(self):
        if self.q:
            return self.q.popleft()

    def display(self):
        print("Stack:", list(self.q))

s = Stack()
s.push(1)
s.push(2)
s.pop()
s.display()
