# Program 10: Generate Binary Numbers using Queue

from collections import deque

def generate_binary(n):
    q = deque()
    q.append("1")
    for _ in range(n):
        front = q.popleft()
        print(front, end=' ')
        q.append(front + "0")
        q.append(front + "1")

generate_binary(10)
