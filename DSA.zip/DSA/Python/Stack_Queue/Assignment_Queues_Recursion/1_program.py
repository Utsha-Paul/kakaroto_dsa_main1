# Program 1: Linear Queue using Array

class Queue:
    def __init__(self, size):
        self.queue = []
        self.size = size

    def enqueue(self, data):
        if len(self.queue) == self.size:
            print("Queue is Full")
            return
        self.queue.append(data)

    def dequeue(self):
        if not self.queue:
            print("Queue is Empty")
            return
        return self.queue.pop(0)

    def display(self):
        print("Queue:", self.queue)

q = Queue(5)
q.enqueue(10)
q.enqueue(20)
q.dequeue()
q.display()
