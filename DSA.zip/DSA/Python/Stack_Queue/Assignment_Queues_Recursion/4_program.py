# Program 4: Multiple Queues in One Array

class KQueues:
    def __init__(self, n, k):
        self.arr = [None]*n
        self.front = [-1]*k
        self.rear = [-1]*k
        self.next = list(range(1, n)) + [-1]
        self.free = 0
        self.k = k

    def enqueue(self, data, qn):
        if self.free == -1:
            print("No space available")
            return
        i = self.free
        self.free = self.next[i]
        if self.front[qn] == -1:
            self.front[qn] = i
        else:
            self.next[self.rear[qn]] = i
        self.next[i] = -1
        self.rear[qn] = i
        self.arr[i] = data

    def dequeue(self, qn):
        if self.front[qn] == -1:
            print("Queue Empty")
            return
        i = self.front[qn]
        self.front[qn] = self.next[i]
        self.next[i] = self.free
        self.free = i
        return self.arr[i]

kq = KQueues(10, 3)
kq.enqueue(15, 0)
kq.enqueue(45, 1)
print(kq.dequeue(0))
