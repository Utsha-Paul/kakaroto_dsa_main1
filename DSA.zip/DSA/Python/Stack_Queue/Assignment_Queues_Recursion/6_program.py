# Program 6: Priority Queue

class PriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, data, priority):
        self.queue.append((priority, data))
        self.queue.sort(reverse=True)

    def dequeue(self):
        if self.queue:
            return self.queue.pop()[1]

    def display(self):
        print("Queue:", self.queue)

pq = PriorityQueue()
pq.enqueue("A", 2)
pq.enqueue("B", 3)
pq.enqueue("C", 1)
pq.dequeue()
pq.display()
