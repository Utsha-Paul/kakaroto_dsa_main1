# Program 6a: Recursive Factorial
def fact(n):
    if n == 0 or n == 1:
        return 1
    return n * fact(n-1)

# Tail Recursive Factorial
def fact_tail(n, acc=1):
    if n == 0:
        return acc
    return fact_tail(n-1, acc*n)

# Recursive Fibonacci
def fib(n):
    if n <= 1:
        return n
    return fib(n-1) + fib(n-2)

# Tail Recursive Fibonacci
def fib_tail(n, a=0, b=1):
    if n == 0:
        return a
    return fib_tail(n-1, b, a+b)

print("Fact(5):", fact(5))
print("Tail Fact(5):", fact_tail(5))
print("Fib(6):", fib(6))
print("Tail Fib(6):", fib_tail(6))
