# Program 9: Decimal to Binary using Stack

def decimal_to_binary(n):
    stack = []
    def convert(num):
        if num == 0:
            return
        stack.append(num % 2)
        convert(num // 2)
    convert(n)
    print("Binary:", ''.join(map(str, stack[::-1])))

decimal_to_binary(25)
