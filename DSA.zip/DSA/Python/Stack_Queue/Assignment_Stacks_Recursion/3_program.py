# Program 3: Check equal number of parentheses using recursion

def check_equal_parentheses(s, i=0, count=0):
    if i == len(s):
        return count == 0
    if s[i] == '(':
        return check_equal_parentheses(s, i+1, count+1)
    elif s[i] == ')':
        if count <= 0:
            return False
        return check_equal_parentheses(s, i+1, count-1)
    return check_equal_parentheses(s, i+1, count)

expr = "((()))"
print("Balanced" if check_equal_parentheses(expr) else "Not Balanced")
