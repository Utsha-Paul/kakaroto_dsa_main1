# Program 2: Stack using Linked List

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def push(self, data):
        new_node = Node(data)
        new_node.next = self.top
        self.top = new_node

    def pop(self):
        if self.top:
            data = self.top.data
            self.top = self.top.next
            return data

    def display(self, node=None):
        if node is None:
            node = self.top
        if node:
            print(node.data, end=' ')
            self.display(node.next)

s = Stack()
s.push(1)
s.push(2)
s.push(3)
s.pop()
s.display()
