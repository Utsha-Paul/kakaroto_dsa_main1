# Program 8: Multiple Stacks in One Array

class KStacks:
    def __init__(self, n, k):
        self.arr = [0]*n
        self.top = [-1]*k
        self.next = list(range(1, n)) + [-1]
        self.free = 0
        self.k = k

    def push(self, item, sn):
        if self.free == -1:
            print("Stack Overflow")
            return
        i = self.free
        self.free = self.next[i]
        self.arr[i] = item
        self.next[i] = self.top[sn]
        self.top[sn] = i

    def pop(self, sn):
        if self.top[sn] == -1:
            print("Stack Underflow")
            return None
        i = self.top[sn]
        self.top[sn] = self.next[i]
        self.next[i] = self.free
        self.free = i
        return self.arr[i]

ks = KStacks(10, 3)
ks.push(15, 0)
ks.push(45, 0)
ks.push(17, 1)
print("Popped:", ks.pop(0))
