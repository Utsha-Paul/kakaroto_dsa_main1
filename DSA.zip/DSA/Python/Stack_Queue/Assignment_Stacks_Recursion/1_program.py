# Program 1: Stack using Array (Recursion not needed)

class Stack:
    def __init__(self):
        self.stack = []

    def push(self, data):
        self.stack.append(data)

    def pop(self):
        if self.stack:
            return self.stack.pop()

    def display(self):
        print("Stack:", self.stack)

s = Stack()
s.push(10)
s.push(20)
s.pop()
s.display()
