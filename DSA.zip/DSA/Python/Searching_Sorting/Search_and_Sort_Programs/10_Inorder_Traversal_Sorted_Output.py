class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def insert(root, key):
    if not root:
        return BSTNode(key)
    if key < root.key:
        root.left = insert(root.left, key)
    else:
        root.right = insert(root.right, key)
    return root

def inorder(root):
    if root:
        inorder(root.left)
        print(root.key, end=" ")
        inorder(root.right)

arr = [50, 30, 20, 40, 70, 60, 80]
root = None
for val in arr:
    root = insert(root, val)

print("In-order traversal (Sorted Output):")
inorder(root)