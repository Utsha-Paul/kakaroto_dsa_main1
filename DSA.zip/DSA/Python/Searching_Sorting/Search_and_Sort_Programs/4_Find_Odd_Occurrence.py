def find_odd_occurrence(arr):
    res = 0
    for num in arr:
        res ^= num
    return res

arr = [2, 3, 2, 3, 5, 5, 7]
print("Number occurring odd number of times:", find_odd_occurrence(arr))